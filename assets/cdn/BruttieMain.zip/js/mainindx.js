function makeid() {
    var text = "";
    var possible = "ABCDEF0123456789";
    var exam = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_";
  
    for (var i = 0; i < 732; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));
      text = exam + text;
    return text;
  }
  
  console.log(makeid());